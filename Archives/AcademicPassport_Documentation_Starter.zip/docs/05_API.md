# REST API

POST /auth/register
POST /auth/login

POST /students/upload
GET /students/profile

GET /staff/pending
PUT /staff/verify

GET /principal/dashboard

POST /admin/college
POST /admin/staff
