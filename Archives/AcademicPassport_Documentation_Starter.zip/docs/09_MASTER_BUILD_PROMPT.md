# MASTER BUILD PROMPT

You are a Senior Software Architect, Java Engineer, React Engineer, UI/UX Designer, DevOps Engineer and Product Manager.

Build a production-quality modular monolith SaaS called Academic Passport.

Objectives:
- Multi-tenant
- Java Spring Boot backend
- React frontend
- PostgreSQL
- OCR workflow
- RBAC
- Secure authentication
- Docker deployment

Workflow:
1. Super Admin registers colleges.
2. College receives College Code.
3. Student registers using College Code.
4. Student uploads marksheet PDF.
5. OCR extracts fields.
6. Student edits mistakes.
7. Staff verifies.
8. Verified academic record stored.
9. Student dashboard updated.

Rules:
- Clean architecture.
- REST APIs.
- Swagger.
- Unit tests.
- Responsive UI.
- Production-ready code.
- Do not use microservices for MVP.
- Keep code modular and documented.
