# Security

- HTTPS
- JWT
- Refresh Tokens
- RBAC
- Password Hashing
- Audit Logs
- Encrypted Storage
- Signed URLs
- Rate Limiting
- DPDP-ready design
