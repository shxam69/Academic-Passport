# Product

## Roles
- Student
- Staff
- Principal
- Super Admin

## Student Workflow
1. Register with College Code
2. Login
3. Upload PDF
4. OCR Extraction
5. Review extracted data
6. Submit
7. Staff verifies
8. View verified results

## Staff Workflow
- Review pending uploads
- Approve / Reject
- Edit OCR mistakes
- Search students

## Principal
- View dashboards
- Reports
- Department analytics

## Super Admin
- Register colleges
- Manage users
- Support tickets
- Monitor platform
