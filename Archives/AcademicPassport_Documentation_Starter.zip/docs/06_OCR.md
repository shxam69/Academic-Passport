# OCR Pipeline

PDF Upload
↓
Virus Scan
↓
OCR Engine
↓
AI Validation
↓
Student Review
↓
Staff Verification
↓
Database
↓
Verified Transcript
