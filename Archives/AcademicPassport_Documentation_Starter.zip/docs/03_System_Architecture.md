# Architecture

Frontend
React + TypeScript + Vite

Backend
Java 21
Spring Boot
Spring Security
JWT
Hibernate

Database
PostgreSQL

Storage
Cloud Object Storage

OCR
Tesseract (Dev)
Google Vision / Azure DI (Prod)

Deployment
Docker + AWS
