# Roadmap

## Phase 0
Planning

## MVP
- Auth
- Upload
- OCR
- Verification
- Dashboard

## V2
- Payments
- QR Verification
- Reports

## V3
- Career Services
- Multi-college
- Mobile App
