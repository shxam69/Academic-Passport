# Academic Passport SaaS

## Overview
Academic Passport is a multi-tenant SaaS platform for Indian colleges that digitizes academic records through secure PDF uploads, OCR extraction, staff verification, and searchable academic records.

## MVP Goal
- Student Registration
- Staff Verification
- Admin College Management
- OCR Extraction
- Verified Academic Record
- Search & Filters

See the numbered documents for details.
