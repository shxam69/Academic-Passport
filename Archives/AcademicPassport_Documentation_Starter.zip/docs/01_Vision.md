# Vision

## Mission
Create India's trusted academic identity platform.

## Problem
- Manual marksheet handling
- Lost PDFs
- Slow verification
- No centralized academic history

## Solution
A secure Academic Passport that stores, verifies and organizes academic records.
