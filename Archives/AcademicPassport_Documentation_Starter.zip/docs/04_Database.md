# Database

Core Tables

- users
- roles
- colleges
- departments
- students
- staff
- semesters
- subjects
- marksheets
- extracted_marks
- verification
- audit_logs
- support_tickets
- subscriptions
- notifications

All tables include tenant (college_id) for multi-tenancy.
